from setuptools import setup, find_packages

setup(
    name = 'src', version="0.0.1",
    description="It's a MLOPS package with wine dataset",
    author="dee.walia20", 
    packages = find_packages(),
    license='MIT'
)